#****************************
#
# Advances in Data Sciences
#
# Recommendation Systems
# Team 3 Presentation
#
# Amitha, Divyansh, Jyoti
#
#****************************

setwd("C:/Users/subhash/OneDrive/Advance DS/Recommendation System")

# If not installed, first install following three packages in R
#install.packages("recommenderlab")
#install.packages("reshape2")
#install.packages("ggplot2")

library(recommenderlab)
library(reshape2)
library(ggplot2)

# Read training file along with header
data<-read.csv("train_v2.csv",header=TRUE)
data <- data[order(data$user, data$movie),]

# Just look at first few lines of this file
head(data)
# Remove 'id' column. We do not need it
data<-data[,-c(1)]
# Check, if removed

data<-data[((data$user<1000) & ((data$movie<1000))),]
#Ratings by user 1
data[data$user==2,]

# Using acast to convert above data as follows:
#       m1  m2   m3   m4
# u1    3   4    2    5
# u2    1   6    5
# u3    4   4    2    5
datamat  <-acast(data, user ~ movie)
# Check the class of datamat
class(datamat)
# Convert it as a matrix
MovieMat <-as.matrix(datamat)

# Convert MovieMat into realRatingMatrix data structure
#   realRatingMatrix is a recommenderlab sparse-matrix like data-structure
realRatMat <- as(MovieMat, "realRatingMatrix")
print(realRatMat)
# normalize the rating matrix
realRatMat_m <- normalize(realRatMat)

# Draw an image plot of raw-ratings & normalized ratings
# A column represents one specific movie and ratings by users
# are shaded.
# Note that some items are always rated 'black' by most users
# while some items are not rated by many users
# On the other hand a few users always give high ratings
# as in some cases a series of black dots cut across items
image(realRatMat, main = "Raw Ratings")       
image(realRatMat_m, main = "Normalized Ratings")

# Can also turn the matrix into a 0-1 binary matrix
realRatMat_b <- binarize(realRatMat, minRating=1)

# Create a recommender object (model)
#
#   We can choose anyone of the following four code lines.
#   They pertain to four different algorithms.
#   UBCF: User-based collaborative filtering
#   IBCF: Item-based collaborative filtering
#      Parameter 'method' decides similarity measure
#      Cosine or Jaccard

recomm = Recommender(realRatMat[1:nrow(realRatMat)],method="UBCF", param=list(normalize = "Z-score",method="Cosine",nn=5))
#recomm =Recommender(r[1:nrow(r)],method="UBCF")
#recomm =Recommender(r[1:nrow(r)],method="UBCF", param=list(normalize = "Z-score",method="Jaccard",nn=5, minRating=1))
#recomm =Recommender(r[1:nrow(r)],method="IBCF", param=list(normalize = "Z-score",method="Jaccard",minRating=1))
#recomm =Recommender(r[1:nrow(r)],method="POPULAR")

# Depending upon your selection, examine what you got

############Create predictions#############################
# This prediction does not predict movie ratings for test.
#   But it fills up the user 'X' item matrix so that
#   for any userid and movieid, I can find predicted rating
#   'type' parameter decides whether you want ratings or top-n items
#   get top-10 recommendations for a user, as:
#   predict(rec, r[1:nrow(r)], type="topNList", n=10)

prediction <- predict(recomm, realRatMat[1:nrow(realRatMat)], type="ratings")

# Study and Compare the following:
originalMat <- as(realRatMat, "matrix")     # Has lots of NAs. 'r' is the original matrix
PredictedMat <- as(prediction, "matrix") # Is full of ratings. NAs disappear

# Convert all your recommendations to list structure
prediction_list<-as(prediction,"list")
head(summary(prediction_list))

#Complete ratings 
fullMovieRatings <- matrix(data =NA, ncol =length(colnames(originalMat)),nrow = nrow(originalMat) )
for(coln in 1:length(colnames(originalMat)))
{
  for (row in 1:nrow(originalMat)) {
    fullMovieRatings[row,coln] <- ifelse(is.na(PredictedMat[row,coln]),originalMat[row,coln],PredictedMat[row,coln])
  }
}

#Test
test<-read.csv("test_v2.csv",header=TRUE)
head(test)
test<-test[((test$user<1000) & ((test$movie<1000))),]

# Convert all your recommendations to list structure
prediction_list<-as(prediction,"list")
head(summary(prediction_list))

class(prediction)
preds <- as(prediction, "data.frame")


ratings<-NULL

for(u in 1:nrow(test))
{
  # Read userid and movieid from columns 2 and 3 of test data
  userid <- test[u,2]
  movieid<-test[u,3]
    # Get as list & then convert to data frame all recommendations for user: userid
  
  u1 <- preds[((preds$user==userid) & ((preds$item==movieid))),]
  
  # Create a (second column) column-id in the data-frame u1 and populate it with row-names
  # Remember (or check) that rownames of u1 contain are by movie-ids
  # We use row.names() function
  #u1$id<-row.names(u1)
  # Now access movie ratings in column 1 of u1
  
  # If no ratings were found, assign 0. You could also
  #   assign user-average
  ratings[u] =ifelse(length(u1)>0,u1$rating,0)
}

length(ratings)
test$newrat <- round(ratings)







